// location - 2digit
// sublocation - 1 digit
// 1 -digit - building-1, gate-2
// 2 digit-building/gate

const locations = [
    { 'id': 11, 'code': 'BLR', name: 'Bangalore' },
    { 'id': 22, 'code': 'CHN', name: 'Chennai' }
];

const subLocations = [
    { id: 111, code: 'BLREC', name: 'Electronic city', belongs_toId: 11, belongs_toName: 'Bangalore' },
    { id: 112, code: 'BLRMNC', name: 'MNC Building', belongs_toId: 11, belongs_toName: 'Bangalore' },
    { id: 113, code: 'BLRJP', name: 'J P Tower', belongs_toId: 11, belongs_toName: 'Bangalore' },
    { id: 221, code: 'CHNEC', name: 'CHN - Electronic city', belongs_toId: 22, belongs_toName: 'Chennai' },
    { id: 222, code: 'CHNMNC', name: 'CHN - MNC Building', belongs_toId: 22, belongs_toName: 'Chennai' },
    { id: 223, code: 'CHNJP', name: 'CHN - J P Tower', belongs_toId: 22, belongs_toName: 'Chennai' }
];

const buildings = [
    { id: 111111, code: 'BLRECB11', name: 'Electronic city B11', belongs_toId: 111, belongs_toName: 'Electronic city' },
    { id: 111112, code: 'BLRECB12', name: 'Electronic city B12', belongs_toId: 111, belongs_toName: 'Electronic city' },
    { id: 111113, code: 'BLRECB13', name: 'Electronic city B13', belongs_toId: 111, belongs_toName: 'Electronic city' },
    { id: 221111, code: 'CHNECB11', name: 'CHN - Electronic city B11', belongs_toId: 221, belongs_toName: 'CHN - Electronic city' },
    { id: 221112, code: 'CHNECB12', name: 'CHN - Electronic city B12', belongs_toId: 221, belongs_toName: 'CHN - Electronic city' },
    { id: 221113, code: 'CHNECB13', name: 'CHN - Electronic city B13', belongs_toId: 221, belongs_toName: 'CHN - Electronic city' },
];

const gates = [
    { id: 111211, code: 'BLRECG11', name: 'Electronic city B11 -G', belongs_toId: 111, belongs_toName: 'Electronic city' },
    { id: 111212, code: 'BLRECG12', name: 'Electronic city B12 -G', belongs_toId: 111, belongs_toName: 'Electronic city' },
    { id: 111213, code: 'BLRECG13', name: 'Electronic city B13 -G', belongs_toId: 111, belongs_toName: 'Electronic city' },
    { id: 221211, code: 'CHNECG11', name: 'CHN - Electronic city B11 -G', belongs_toId: 221, belongs_toName: 'CHN - Electronic city' },
    { id: 221212, code: 'CHNECG12', name: 'CHN - Electronic city B12 -G', belongs_toId: 221, belongs_toName: 'CHN - Electronic city' },
    { id: 221213, code: 'CHNECG13', name: 'CHN - Electronic city B13 -G', belongs_toId: 221, belongs_toName: 'CHN - Electronic city' },
];


var express = require('express');
var router = express.Router();

var dbmodule = require('./dbmodule');

router.get('/', (req, res) => {

    res.send(locations);
});

router.get('/:id/subloc', (req, res) => {
    const id = +req.params.id;
    res.send(subLocations.filter(x => x.belongs_toId == id));
});

router.get('/:id/subloc/:sid/gates', (req, res) => {
    const sid = +req.params.sid;
    const subLocId = subLocations.find(x => x.id === sid).id;
    res.send(gates.filter(x => x.belongs_toId == subLocId));
});

router.get('/:id/subloc/:sid/building', (req, res) => {
    const sid = +req.params.sid;
    const subLocId = subLocations.find(x => x.id === sid).id;
    res.send(buildings.filter(x => x.belongs_toId == subLocId));
});

router.post('/', (req, res) => {
    dbmodule.addLocation(req, res);
});


module.exports = router;