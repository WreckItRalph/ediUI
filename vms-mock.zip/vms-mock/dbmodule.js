var mongojs = require("mongojs");
var db = mongojs('vms', ['location']); 

var dbModule = {
    addLocation : (req,res) => {
        db.location.save(req.body,()=>{
            res.send({success:true})
            
        },
        (err)=>{
            res.sendStatus(500);
        });
        
    }
};



module.exports = dbModule;