const mockBookingSingle = { id: '1234', name: 'Sachin', mobile: '9286138083', email: 'sachin.gupta192160@gmail.com', organization: 'Infosys', toMeet: 'Gupta', purpose: 'Delivery Person', location: 'Bangalore', subLocation: 'Electronic city', "buildings": ["Electronic city B11"], "gates": ["Electronic city B12 -G"], fromDate: '2018-12-31T18:30:00.000Z', toDate: '2019-01-31T18:30:00.000Z', laptop: 'laptop', nightWork: true, remarks: 'remarks', photo: null, groupVisitors: [], visitType: 'single', status: 'REQUEST_PENDING' };
const mockGroupBooking = { "id": "2345", "name": "Sachin", "mobile": "9286138083", "email": "sachin.gupta192160@gmail.com", "organization": "Infosys", "toMeet": "Gupta", "purpose": "Delivery Person", "location": "Bangalore", "subLocation": "Electronic city", "buildings": ["Electronic city B11"], "gates": ["Electronic city B12 -G"], "fromDate": "2019-05-30T18:30:00.000Z", "toDate": "2019-06-01T04:30:00.000Z", "laptopDetail": "", "nightWork": true, "remarks": "group remark", "photo": null, visitType: 'group', "groupVisitors": [{ "name": "arundam ", "mobile": "123yu8i9", "laptopDetail": "sdlcnvm" }, { "name": "sdalfnka", "mobile": null, "laptopDetail": null }], "status": "REQUEST_APPROVED", "imageLink": null }
const bookingarray = [mockBookingSingle, mockGroupBooking];

var express = require('express');
var router = express.Router();
var fileUpload = require('express-fileupload');
var path = require('path');
router.get('/counts', (req, res) => {
    res.send({
        data: 100
    });
});

router.get('/', (req, res) => {
    res.send(bookingarray);
});

router.post('/', fileUpload(), (req, res) => {
    console.log(req.files);
    console.log('body', req.body)
        // req.files = req.files || {};
    let sampleFile = req.files['uploadFile'];
    bookingarray.push(req.body);
    const x = Object.assign(req.body, { id: bookingarray.length });

    // Use the mv() method to place the file somewhere on your server
    sampleFile.mv(path.join(__dirname, 'upload', 'fileUploadVisitor.txt'), function(err) {
        if (err)
            return res.status(500).send(err);

        res.send({});
    });
    //res.send(x);
});

router.put('/', (req, res) => {
    const x = req.body;
    let index = bookingarray.find(e => e.id == x.id);
    if (index >= 0) {
        bookingarray.splice(index, 1, x);
    }
    res.send(x);
});

router.post('/print', (req, res) => {
    console.log('printing');
    res.send(req.body);
});

module.exports = router;