var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var location = require('./location');
var path = require('path');
var visitors = require('./visitors');
var download = require('./download');
const fileUpload = require('express-fileupload');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use('*', (req, res) => {
    //console.log(req);
    req.next();
});
app.use(express.static(path.join(__dirname, 'public')));
app.use(function(req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    next();
});



app.use('/locations', location);
app.use('/visitors', visitors);
app.use('/download', download);
app.post('/form', fileUpload(), function(req, res) {

    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let sampleFile = req.files.fileToUpload;
    console.log(req.files);
    // Use the mv() method to place the file somewhere on your server
    sampleFile.mv(path.join(__dirname, 'upload', 'fileUpload.txt'), function(err) {
        if (err)
            return res.status(500).send(err);

        res.send('File uploaded!');
    });
});
app.get('/', (req, res) => {
    res.send('Hello world');
});


app.post('/', (req, res) => {
    console.log(req);
    res.send(
        [{
            empNo: 749241,
            appRoleName: 'Location Admin',
            delegationOnBehalfOf: 'Vidya',
            startDate: new Date().toISOString(),
            endDate: new Date().toISOString(),
            contextName: 'sublocation',
            contextValue: 'Bangalore',
            tranId: 'string'
        }]);
});

app.listen(8001, () => {
    console.log('server started at port: 8001');
});

app.listen(8928, () => {
    console.log('started on 8928');
});
app.listen(8004, () => {
    console.log('started on 8004');
});
app.listen(8005, () => {
    console.log('started on 8005');
});