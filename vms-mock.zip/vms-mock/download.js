var express = require('express');
var router = express.Router();
var path = require('path');


router.post('/', (req, res) => {
    console.log(req);
    res.sendFile(path.join(__dirname, 'public/text.txt'));
});

router.get('/', (req, res) => {
    console.log(req);
    res.sendFile(path.join(__dirname, 'public/text.txt'));
});


module.exports = router;